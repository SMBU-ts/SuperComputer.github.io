#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <chrono>
#include <algorithm>
#include <string>

using namespace std;

/*
  Sequential PCG solver for fictitious-domain Poisson problem:
    -(a w_x)_x - (b w_y)_y = F  on interior grid, w=0 on box boundary.
  Geometry (case #6): D = { (x,y): |x| + |y| < 2,  y < 1 }
  Box �� = [-2,2] x [-2,1]
  Discretization: eq. (10)-(14); inner product (8); stopping (17). �� = h^2.
*/

struct Grid {
    int M, N;                 // steps in x,y (M,N); interior has (M-1)*(N-1)
    double A1 = -2, B1 = 2;   // x in [A1,B1]
    double A2 = -2, B2 = 1;   // y in [A2,B2]
    double h1, h2, h, eps;    // steps and epsilon=h^2
    vector<double> x, y;

    Grid(int M_, int N_) : M(M_), N(N_) {
        h1 = (B1 - A1) / M;
        h2 = (B2 - A2) / N;
        h  = (h1 > h2 ? h1 : h2);
        eps = h * h;
        x.resize(M + 1);
        y.resize(N + 1);
        for (int i = 0; i <= M; i++) x[i] = A1 + i * h1;
        for (int j = 0; j <= N; j++) y[j] = A2 + j * h2;
    }
};

// D = {|x|+|y|<2, y<1}
inline bool inD(double x, double y) {
    return (fabs(x) + fabs(y) < 2.0) && (y < 1.0);
}

// vertical segment intersection length with D at x = x0, between y0..y1
double vert_len_in_D(double x0, double y0, double y1) {
    // For fixed x0, D projects to y in (L, U), with L=-2+|x0|, U=min(2-|x0|, 1)
    double L = -2.0 + fabs(x0);
    double U = min(2.0 - fabs(x0), 1.0);
    if (L >= U) return 0.0;
    double a = max(L, min(y0, y1));
    double b = min(U, max(y0, y1));
    return (b > a ? (b - a) : 0.0);
}

// horizontal segment intersection length with D at y = y0, between x0..x1
double horiz_len_in_D(double y0, double x0, double x1) {
    if (y0 >= 1.0) return 0.0;           // cut by y<1
    if (fabs(y0) >= 2.0) return 0.0;     // outside diamond vertically
    // For fixed y0, D projects to x in (L, U) with L=-2+|y0|, U= 2-|y0|
    double L = -2.0 + fabs(y0);
    double U =  2.0 - fabs(y0);
    if (L >= U) return 0.0;
    double a = max(L, min(x0, x1));
    double b = min(U, max(x0, x1));
    return (b > a ? (b - a) : 0.0);
}

// approximate area fraction of cell ��_ij �� D by small tensor sampling
double cell_area_fraction_in_D(double xL, double xR,
                               double yB, double yT,
                               int samples = 5)
{
    int cnt = 0, tot = samples * samples;
    for (int si = 0; si < samples; ++si) {
        double xi = xL + (si + 0.5) * (xR - xL) / samples;
        for (int sj = 0; sj < samples; ++sj) {
            double yj = yB + (sj + 0.5) * (yT - yB) / samples;
            if (inD(xi, yj)) ++cnt;
        }
    }
    return static_cast<double>(cnt) / static_cast<double>(tot);
}

struct Problem {
    Grid G;
    vector<vector<double>> a, b, F;   // a_{i,j}, b_{i,j}, F on interior

    Problem(int M, int N) : G(M, N) {
        a.assign(G.M + 1, vector<double>(G.N + 1, 0.0));
        b.assign(G.M + 1, vector<double>(G.N + 1, 0.0));
        F.assign(G.M + 1, vector<double>(G.N + 1, 0.0));
        build_coefficients();
        build_rhs();
    }

    void build_coefficients() {
        // a_{ij}: vertical half-edge at x_{i-1/2}
        for (int i = 1; i <= G.M; i++) {
            double x_half = G.x[i] - 0.5 * G.h1;
            for (int j = 1; j <= G.N; j++) {
                double y0 = G.y[j] - 0.5 * G.h2;
                double y1 = G.y[j] + 0.5 * G.h2;
                double l  = vert_len_in_D(x_half, y0, y1);
                a[i][j]   = (l / G.h2) + (1.0 - l / G.h2) / G.eps;
            }
        }
        // b_{ij}: horizontal half-edge at y_{j-1/2}
        for (int i = 1; i <= G.M; i++) {
            double x0 = G.x[i] - 0.5 * G.h1;
            double x1 = G.x[i] + 0.5 * G.h1;
            for (int j = 1; j <= G.N; j++) {
                double y_half = G.y[j] - 0.5 * G.h2;
                double l      = horiz_len_in_D(y_half, x0, x1);
                b[i][j]       = (l / G.h1) + (1.0 - l / G.h1) / G.eps;
            }
        }
    }

    void build_rhs() {
        // F_{ij} = average of f in cell; here f=1 in D else 0
        for (int i = 1; i < G.M; i++) {
            double xL = G.x[i] - 0.5 * G.h1;
            double xR = G.x[i] + 0.5 * G.h1;
            for (int j = 1; j < G.N; j++) {
                double yB   = G.y[j] - 0.5 * G.h2;
                double yT   = G.y[j] + 0.5 * G.h2;
                double frac = cell_area_fraction_in_D(xL, xR, yB, yT, 5);
                F[i][j]     = frac;
            }
        }
    }

    // Apply A to w on interior
    void apply_A(const vector<vector<double>>& w,
                 vector<vector<double>>& out) const
    {
        for (int i = 1; i < G.M; i++) {
            for (int j = 1; j < G.N; j++) {
                double termx =
                    (a[i + 1][j] * (w[i + 1][j] - w[i][j]) -
                     a[i][j]     * (w[i][j]     - w[i - 1][j])) / (G.h1 * G.h1);

                double termy =
                    (b[i][j + 1] * (w[i][j + 1] - w[i][j]) -
                     b[i][j]     * (w[i][j]     - w[i][j - 1])) / (G.h2 * G.h2);

                out[i][j] = -(termx + termy);
            }
        }
    }

    // z = D^{-1} r ; D_ij = ((a_{i+1,j}+a_{i,j})/h1^2 + (b_{i,j+1}+b_{i,j})/h2^2)
    void apply_Dinv(const vector<vector<double>>& r,
                    vector<vector<double>>& z) const
    {
        for (int i = 1; i < G.M; i++) {
            for (int j = 1; j < G.N; j++) {
                double Dij =
                    ((a[i + 1][j] + a[i][j]) / (G.h1 * G.h1) +
                     (b[i][j + 1] + b[i][j]) / (G.h2 * G.h2));
                z[i][j] = r[i][j] / Dij;
            }
        }
    }

    // (u,v) = sum h1*h2 u_ij v_ij over interior
    double inner(const vector<vector<double>>& u,
                 const vector<vector<double>>& v) const
    {
        double s = 0.0;
        for (int i = 1; i < G.M; i++)
            for (int j = 1; j < G.N; j++)
                s += u[i][j] * v[i][j];
        return s * (G.h1 * G.h2);
    }

    double normE(const vector<vector<double>>& u) const {
        return std::sqrt(inner(u, u));
    }

    struct Result {
        int iters = 0;
        double lastDiff = 0.0;   // here: residual norm ||r_k||_E
        double timeSec = 0.0;
        vector<vector<double>> w;
    };

    // Preconditioned Conjugate Gradient (PCG) with Jacobi preconditioner
    Result solve(double delta = 1e-6,
                 int maxIter = 20000,
                 bool verbose = false)
    {
        // allocate fields
        vector<vector<double>> w (G.M + 1, vector<double>(G.N + 1, 0.0)); // solution
        vector<vector<double>> r (G.M + 1, vector<double>(G.N + 1, 0.0)); // residual
        vector<vector<double>> z (G.M + 1, vector<double>(G.N + 1, 0.0)); // precond residual
        vector<vector<double>> p (G.M + 1, vector<double>(G.N + 1, 0.0)); // search dir
        vector<vector<double>> Ap(G.M + 1, vector<double>(G.N + 1, 0.0)); // A p

        auto t0 = chrono::high_resolution_clock::now();

        // initial guess w=0 => r = F - A w = F
        for (int i = 1; i < G.M; i++)
            for (int j = 1; j < G.N; j++)
                r[i][j] = F[i][j];

        apply_Dinv(r, z);
        // initial search direction
        p = z;

        double rz_old = inner(r, z);
        double resNorm = normE(r);

        if (verbose) {
            cerr << "PCG initial residual ||r0||_E = " << resNorm << "\n";
        }

        int k = 0;
        while (k < maxIter && resNorm > delta) {
            // Ap = A p
            apply_A(p, Ap);

            double pAp = inner(p, Ap);
            double alpha = rz_old / pAp;

            // w_{k+1} = w_k + alpha * p_k
            // r_{k+1} = r_k - alpha * A p_k
            for (int i = 1; i < G.M; i++) {
                for (int j = 1; j < G.N; j++) {
                    w[i][j] += alpha * p[i][j];
                    r[i][j] -= alpha * Ap[i][j];
                }
            }

            resNorm = normE(r);
            ++k;

            if (verbose && (k % 100 == 0)) {
                cerr << "iter " << k
                     << "  ||r||_E=" << resNorm << "\n";
            }

            if (resNorm < delta) break;

            // z_{k+1} = D^{-1} r_{k+1}
            apply_Dinv(r, z);

            double rz_new = inner(r, z);
            double beta   = rz_new / rz_old;
            rz_old = rz_new;

            // p_{k+1} = z_{k+1} + beta * p_k
            for (int i = 1; i < G.M; i++)
                for (int j = 1; j < G.N; j++)
                    p[i][j] = z[i][j] + beta * p[i][j];
        }

        auto t1 = chrono::high_resolution_clock::now();
        double sec = chrono::duration<double>(t1 - t0).count();

        Result R;
        R.iters    = k;
        R.lastDiff = resNorm;  // store final residual norm
        R.timeSec  = sec;
        R.w.swap(w);
        return R;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cout << fixed << setprecision(10);
    cout << "# Sequential PCG solver for fictitious-domain Poisson problem (case #6)\n";
    cout << "# Box [-2,2]x[-2,1], f=1 in D, 0 outside. Epsilon = h^2.\n";
    cout << "# Columns: M N  iterations  ||r||_E  time_sec\n";

    const int Ms[2] = { 400, 800 };
    const int Ns[2] = { 600, 1200 };
    for (int idx = 0; idx < 2; ++idx) {
        int M = Ms[idx], N = Ns[idx];
        Problem P(M, N);

        // ���԰���Ҫ�����ݲ�����ͳһ�� 1e-6
        double delta = 1e-6;

        Problem::Result R = P.solve(delta, 20000, false);

        cout << setw(3) << M << " " << setw(3) << N << "  "
             << setw(8) << R.iters << "  "
             << setw(12) << R.lastDiff << "  "
             << setw(10) << R.timeSec << "\n";

        // dump CSV for plotting
        string fname = string("solution_M") + to_string(M)
                     + "_N" + to_string(N) + ".csv";
        ofstream fo(fname.c_str());
        fo << "x,y,u\n";
        for (int i = 0; i <= P.G.M; i++)
            for (int j = 0; j <= P.G.N; j++)
                fo << P.G.x[i] << "," << P.G.y[j] << "," << R.w[i][j] << "\n";
        fo.close();
        cerr << "Saved " << fname << "\n";
    }

    return 0;
}
