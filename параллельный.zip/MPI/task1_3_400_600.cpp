// task1_mpi.cpp  �� MPI 2D ��ֽ� + Jacobi Ԥ���� PCG����ѡ OpenMP��
// ��Ŀ #6��D = { |x|+|y|<2, y<1 }������ ��=[-2,2]��[-2,1]����=h^2

#include <mpi.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>

// ======== ȫ��������ϵ��������ԭ�� task1_2 ͬһ��������ɢ�� ========

// ���κ��� �� = [-2,2] x [-2,1]
struct Grid {
    int M, N;          // �ֳ� M, N ��С���� => M+1, N+1 �����
    double A1 = -2.0, B1 = 2.0;
    double A2 = -2.0, B2 = 1.0;
    double h1, h2, h, eps;
    std::vector<double> x, y;

    Grid(int M_, int N_) : M(M_), N(N_) {
        h1 = (B1 - A1) / M;
        h2 = (B2 - A2) / N;
        h = (h1 > h2 ? h1 : h2);
        eps = h * h;
        x.resize(M + 1);
        y.resize(N + 1);
        for (int i = 0; i <= M; ++i) x[i] = A1 + i * h1;
        for (int j = 0; j <= N; ++j) y[j] = A2 + j * h2;
    }
};

// ��ļ��Σ�D = { (x,y): |x| + |y| < 2,  y < 1 }
inline bool inD(double x, double y) {
    return (std::fabs(x) + std::fabs(y) < 2.0) && (y < 1.0);
}

double vert_len_in_D(double x0, double y0, double y1) {
    double L = -2.0 + std::fabs(x0);
    double U = std::min(2.0 - std::fabs(x0), 1.0);
    if (L >= U) return 0.0;
    double a = std::max(L, std::min(y0, y1));
    double b = std::min(U, std::max(y0, y1));
    return (b > a ? (b - a) : 0.0);
}

double horiz_len_in_D(double y0, double x0, double x1) {
    if (y0 >= 1.0) return 0.0;
    if (std::fabs(y0) >= 2.0) return 0.0;
    double L = -2.0 + std::fabs(y0);
    double U = 2.0 - std::fabs(y0);
    if (L >= U) return 0.0;
    double a = std::max(L, std::min(x0, x1));
    double b = std::min(U, std::max(x0, x1));
    return (b > a ? (b - a) : 0.0);
}

// ϸ�ֲ������㵥Ԫ�� f=1 �� D �е��������
double cell_area_fraction_in_D(double xL, double xR,
    double yB, double yT,
    int samples = 5)
{
    int cnt = 0, tot = samples * samples;
    for (int si = 0; si < samples; ++si) {
        double xi = xL + (si + 0.5) * (xR - xL) / samples;
        for (int sj = 0; sj < samples; ++sj) {
            double yj = yB + (sj + 0.5) * (yT - yB) / samples;
            if (inD(xi, yj)) ++cnt;
        }
    }
    return double(cnt) / double(tot);
}

// ȫ��ϵ�� a[i][j], b[i][j], F[i][j]�����н��̶�����һ�ݣ�С�ߴ翪�����Խ��ܣ�
struct Coeffs {
    Grid G;
    std::vector<std::vector<double>> a, b, F;

    Coeffs(int M, int N) : G(M, N) {
        a.assign(G.M + 1, std::vector<double>(G.N + 1, 0.0));
        b.assign(G.M + 1, std::vector<double>(G.N + 1, 0.0));
        F.assign(G.M + 1, std::vector<double>(G.N + 1, 0.0));
        build_coefficients();
        build_rhs();
    }

    void build_coefficients() {
        // a(i-1/2,j)
        for (int i = 1; i <= G.M; ++i) {
            for (int j = 1; j <= G.N; ++j) {
                double xh = G.x[i] - 0.5 * G.h1;
                double y0 = G.y[j] - 0.5 * G.h2;
                double y1 = G.y[j] + 0.5 * G.h2;
                double l = vert_len_in_D(xh, y0, y1);
                a[i][j] = (l / G.h2) + (1.0 - l / G.h2) / G.eps;
            }
        }
        // b(i,j-1/2)
        for (int i = 1; i <= G.M; ++i) {
            for (int j = 1; j <= G.N; ++j) {
                double x0 = G.x[i] - 0.5 * G.h1;
                double x1 = G.x[i] + 0.5 * G.h1;
                double yh = G.y[j] - 0.5 * G.h2;
                double l = horiz_len_in_D(yh, x0, x1);
                b[i][j] = (l / G.h1) + (1.0 - l / G.h1) / G.eps;
            }
        }
    }

    void build_rhs() {
        for (int i = 1; i < G.M; ++i) {
            for (int j = 1; j < G.N; ++j) {
                double xL = G.x[i] - 0.5 * G.h1;
                double xR = G.x[i] + 0.5 * G.h1;
                double yB = G.y[j] - 0.5 * G.h2;
                double yT = G.y[j] + 0.5 * G.h2;
                F[i][j] = cell_area_fraction_in_D(xL, xR, yB, yT, 5);
            }
        }
    }
};

// ======== ��Ŀ 4����ά�����㷨 ========

// һά�� K ���ڲ���� (1..K) ���ȷָ� parts �ݣ�ʹ���������ݲ���� 1
void split_1d(int K, int parts,
    std::vector<int>& beg,
    std::vector<int>& end)
{
    beg.resize(parts);
    end.resize(parts);
    int base = K / parts;
    int rem = K % parts;
    int cur = 1;
    for (int p = 0; p < parts; ++p) {
        int cnt = base + (p < rem ? 1 : 0);
        beg[p] = cur;
        end[p] = cur + cnt - 1;
        cur += cnt;
    }
}

// ѡ�� Px * Py = P �ķֽ⣬ʹ��
// 1) ÿ������� nx/ny �� [1/2, 2]
// 2) ÿ����������������Ľ������ �� 1  (�� split_1d �Զ���֤)
void choose_2d_decomposition(int M, int N, int P,
    int& Px, int& Py)
{
    int innerX = M - 1;   // �ڲ������ (1..M-1)
    int innerY = N - 1;   // �ڲ������ (1..N-1)

    double bestScore = 1e100;
    Px = 1;
    Py = P;

    for (int px = 1; px <= P; ++px) {
        if (P % px) continue;
        int py = P / px;

        int nx_min = innerX / px;
        int nx_max = nx_min + ((innerX % px) ? 1 : 0);
        int ny_min = innerY / py;
        int ny_max = ny_min + ((innerY % py) ? 1 : 0);

        // �����µı�����Χ
        double r_min = double(nx_min) / double(ny_max);
        double r_max = double(nx_max) / double(ny_min);

        if (r_min < 0.5 - 1e-12) continue;
        if (r_max > 2.0 + 1e-12) continue;

        double block_aspect = (double(innerX) / px) / (double(innerY) / py);
        double score = std::fabs(block_aspect - 1.0);
        if (score < bestScore) {
            bestScore = score;
            Px = px;
            Py = py;
        }
    }
}

// ������ȫ���ڲ�����еķ�Χ��
// i = i0..i1  (1..M-1), j = j0..j1  (1..N-1)
struct SubDomain {
    int i0, i1;
    int j0, j1;
    int nx() const { return i1 - i0 + 1; }
    int ny() const { return j1 - j0 + 1; }
};

// ======== �ֲ����������㣩 ========

struct LocalField {
    int nx, ny;              // �ڲ������
    std::vector<double> data; // ��С (nx+2)*(ny+2)

    LocalField() : nx(0), ny(0) {}
    LocalField(int nx_, int ny_) { resize(nx_, ny_); }

    void resize(int nx_, int ny_) {
        nx = nx_;
        ny = ny_;
        data.assign((nx + 2) * (ny + 2), 0.0);
    }

    inline double& operator()(int i, int j) {
        // i: 0..nx+1, j: 0..ny+1
        return data[i * (ny + 2) + j];
    }
    inline const double& operator()(int i, int j) const {
        return data[i * (ny + 2) + j];
    }
};

// ======== ������MPI �ϵ��ڻ��뷶�� ========

double inner_mpi(const Coeffs& C, const SubDomain& sd,
    const LocalField& u, const LocalField& v,
    MPI_Comm comm)
{
    const Grid& G = C.G;
    int nx = sd.nx();
    int ny = sd.ny();
    double local_sum = 0.0;
    for (int iL = 1; iL <= nx; ++iL) {
        for (int jL = 1; jL <= ny; ++jL) {
            local_sum += u(iL, jL) * v(iL, jL);
        }
    }
    double global_sum = 0.0;
    MPI_Allreduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, comm);
    return global_sum * (G.h1 * G.h2);
}

double normE_mpi(const Coeffs& C, const SubDomain& sd,
    const LocalField& u, MPI_Comm comm)
{
    double val = inner_mpi(C, sd, u, u, comm);
    return std::sqrt(val);
}

// ======== ��������㣨�ĸ����� ========

void exchange_halo(LocalField& u, const SubDomain& sd,
    MPI_Comm comm2d,
    int nbr_left, int nbr_right,
    int nbr_down, int nbr_up)
{
    int nx = sd.nx();
    int ny = sd.ny();
    int maxlen = std::max(nx, ny);
    std::vector<double> sendbuf(maxlen), recvbuf(maxlen);

    // ---- ˮƽ������ -> �����飻�� -> ������ ----
    // 1) �����ұ߽��� nx �����ڣ��������ڵ��ұ߽絽������ 0
    if (ny > 0) {
        for (int j = 1; j <= ny; ++j)
            sendbuf[j - 1] = u(nx, j);

        MPI_Sendrecv(sendbuf.data(), ny, MPI_DOUBLE, nbr_right, 0,
            recvbuf.data(), ny, MPI_DOUBLE, nbr_left, 0,
            comm2d, MPI_STATUS_IGNORE);

        if (nbr_left != MPI_PROC_NULL) {
            for (int j = 1; j <= ny; ++j)
                u(0, j) = recvbuf[j - 1];
        }
        else { // ��߽磺Dirichlet 0
            for (int j = 1; j <= ny; ++j)
                u(0, j) = 0.0;
        }
    }

    // 2) ������߽��� 1 �����ڣ��������ڵ���߽絽������ nx+1
    if (ny > 0) {
        for (int j = 1; j <= ny; ++j)
            sendbuf[j - 1] = u(1, j);

        MPI_Sendrecv(sendbuf.data(), ny, MPI_DOUBLE, nbr_left, 1,
            recvbuf.data(), ny, MPI_DOUBLE, nbr_right, 1,
            comm2d, MPI_STATUS_IGNORE);

        if (nbr_right != MPI_PROC_NULL) {
            for (int j = 1; j <= ny; ++j)
                u(nx + 1, j) = recvbuf[j - 1];
        }
        else {
            for (int j = 1; j <= ny; ++j)
                u(nx + 1, j) = 0.0;
        }
    }

    // ---- ��ֱ������ -> �����飻�� -> ������ ----
    // 3) �����ϱ߽��� ny �����ڣ��������ڵ��ϱ߽絽������ 0
    if (nx > 0) {
        for (int i = 1; i <= nx; ++i)
            sendbuf[i - 1] = u(i, ny);

        MPI_Sendrecv(sendbuf.data(), nx, MPI_DOUBLE, nbr_up, 2,
            recvbuf.data(), nx, MPI_DOUBLE, nbr_down, 2,
            comm2d, MPI_STATUS_IGNORE);

        if (nbr_down != MPI_PROC_NULL) {
            for (int i = 1; i <= nx; ++i)
                u(i, 0) = recvbuf[i - 1];
        }
        else {
            for (int i = 1; i <= nx; ++i)
                u(i, 0) = 0.0;
        }
    }

    // 4) �����±߽��� 1 �����ڣ��������ڵ��±߽絽������ ny+1
    if (nx > 0) {
        for (int i = 1; i <= nx; ++i)
            sendbuf[i - 1] = u(i, 1);

        MPI_Sendrecv(sendbuf.data(), nx, MPI_DOUBLE, nbr_down, 3,
            recvbuf.data(), nx, MPI_DOUBLE, nbr_up, 3,
            comm2d, MPI_STATUS_IGNORE);

        if (nbr_up != MPI_PROC_NULL) {
            for (int i = 1; i <= nx; ++i)
                u(i, ny + 1) = recvbuf[i - 1];
        }
        else {
            for (int i = 1; i <= nx; ++i)
                u(i, ny + 1) = 0.0;
        }
    }
}

// ======== �ֲ����� A �� Jacobi Ԥ���� D^{-1} ========

// y = A w ��ֻ�ڱ������ڲ����㣬w �Ѿ������µ�����㣩
void apply_A_local(const Coeffs& C, const SubDomain& sd,
    const LocalField& w, LocalField& y)
{
    const Grid& G = C.G;
    int nx = sd.nx();
    int ny = sd.ny();

    for (int iL = 1; iL <= nx; ++iL) {
        int i = sd.i0 + iL - 1;   // ȫ�� i
        for (int jL = 1; jL <= ny; ++jL) {
            int j = sd.j0 + jL - 1; // ȫ�� j

            double wij = w(iL, jL);

            double termx =
                (C.a[i + 1][j] * (w(iL + 1, jL) - wij)
                    - C.a[i][j] * (wij - w(iL - 1, jL))) / (G.h1 * G.h1);

            double termy =
                (C.b[i][j + 1] * (w(iL, jL + 1) - wij)
                    - C.b[i][j] * (wij - w(iL, jL - 1))) / (G.h2 * G.h2);

            y(iL, jL) = -(termx + termy);
        }
    }
}

// z = D^{-1} r ��D �� A �ĶԽǣ�
void apply_Dinv_local(const Coeffs& C, const SubDomain& sd,
    const LocalField& r, LocalField& z)
{
    const Grid& G = C.G;
    int nx = sd.nx();
    int ny = sd.ny();

    for (int iL = 1; iL <= nx; ++iL) {
        int i = sd.i0 + iL - 1;
        for (int jL = 1; jL <= ny; ++jL) {
            int j = sd.j0 + jL - 1;

            double Dij =
                ((C.a[i + 1][j] + C.a[i][j]) / (G.h1 * G.h1) +
                    (C.b[i][j + 1] + C.b[i][j]) / (G.h2 * G.h2));

            z(iL, jL) = r(iL, jL) / Dij;
        }
    }
}

// ======== PCG ���� (MPI ��) ========

struct PCGResult {
    int    iters = 0;
    double resNorm = 0.0;
    double timeSec = 0.0;
};

PCGResult solve_pcg_mpi(const Coeffs& C, const SubDomain& sd,
    MPI_Comm comm2d,
    int nbr_left, int nbr_right,
    int nbr_down, int nbr_up,
    double delta, int maxIter)
{
    int rank;
    MPI_Comm_rank(comm2d, &rank);

    int nx = sd.nx();
    int ny = sd.ny();

    LocalField w(nx, ny), r(nx, ny), z(nx, ny), p(nx, ny), Ap(nx, ny);

    // ��ʼ�� w = 0 => r = F - A w = F
    for (int iL = 1; iL <= nx; ++iL) {
        int i = sd.i0 + iL - 1;
        for (int jL = 1; jL <= ny; ++jL) {
            int j = sd.j0 + jL - 1;
            r(iL, jL) = C.F[i][j];
        }
    }

    apply_Dinv_local(C, sd, r, z);

    for (int iL = 1; iL <= nx; ++iL)
        for (int jL = 1; jL <= ny; ++jL)
            p(iL, jL) = z(iL, jL);

    double rz_old = inner_mpi(C, sd, r, z, comm2d);
    double resn = normE_mpi(C, sd, r, comm2d);

    if (rank == 0) {
        std::cout << "Initial residual ||r0||_E = " << resn << "\n";
    }
    if (resn < delta) {
        PCGResult R;
        R.iters = 0;
        R.resNorm = resn;
        R.timeSec = 0.0;
        return R;
    }

    double t0 = MPI_Wtime();
    int k = 0;

    for (; k < maxIter; ++k) {
        // 1) ���� p �������
        exchange_halo(p, sd, comm2d, nbr_left, nbr_right, nbr_down, nbr_up);

        // 2) Ap = A p
        apply_A_local(C, sd, p, Ap);

        double pAp = inner_mpi(C, sd, p, Ap, comm2d);
        double alpha = rz_old / pAp;

        // 3) w = w + alpha p;  r = r - alpha Ap
        for (int iL = 1; iL <= nx; ++iL) {
            for (int jL = 1; jL <= ny; ++jL) {
                w(iL, jL) += alpha * p(iL, jL);
                r(iL, jL) -= alpha * Ap(iL, jL);
            }
        }

        double res2 = inner_mpi(C, sd, r, r, comm2d);
        resn = std::sqrt(res2);

        if (rank == 0 && (k + 1) % 50 == 0) {
            std::cout << "iter " << (k + 1)
                << ", ||r||_E = " << resn << "\n";
        }

        if (resn < delta) { ++k; break; }

        // 4) z = D^{-1} r
        apply_Dinv_local(C, sd, r, z);

        double rz_new = inner_mpi(C, sd, r, z, comm2d);
        double beta = rz_new / rz_old;
        rz_old = rz_new;

        // 5) p = z + beta p
        for (int iL = 1; iL <= nx; ++iL) {
            for (int jL = 1; jL <= ny; ++jL) {
                p(iL, jL) = z(iL, jL) + beta * p(iL, jL);
            }
        }
    }

    double t1 = MPI_Wtime();

    PCGResult R;
    R.iters = k;
    R.resNorm = resn;
    R.timeSec = t1 - t0;
    return R;
}

// ======== main��������� + MPI-PCG ��� ========

int main(int argc, char** argv)
{
    MPI_Init(&argc, &argv);

    int world_rank, world_size;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    const int M = 400;
    const int N = 600;
    const double delta = 1e-6;

    // ---------- 1. ѡ���ά���� (��Ŀ�� 4 ��) ----------
    int Px, Py;
    choose_2d_decomposition(M, N, world_size, Px, Py);

    if (world_rank == 0) {
        std::cout << "Global grid: M = " << M
            << ", N = " << N << "\n";
        std::cout << "MPI processes: " << world_size << "\n";
        std::cout << "2D decomposition: Px = " << Px
            << ", Py = " << Py << "  (Px*Py = "
            << Px * Py << ")\n";
    }

    if (Px * Py != world_size) {
        if (world_rank == 0) {
            std::cerr << "Error: cannot factor " << world_size
                << " into Px*Py with required conditions.\n";
        }
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    // һά�����ڲ���� 1..M-1, 1..N-1
    int innerX = M - 1;
    int innerY = N - 1;
    std::vector<int> iBeg, iEnd, jBeg, jEnd;
    split_1d(innerX, Px, iBeg, iEnd);
    split_1d(innerY, Py, jBeg, jEnd);

    // ---------- 2. �����ѿ������� ----------
    int dims[2] = { Px, Py };
    int periods[2] = { 0, 0 };
    MPI_Comm comm2d;
    MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, 0, &comm2d);

    int coords[2];
    MPI_Cart_coords(comm2d, world_rank, 2, coords);
    int cx = coords[0];  // x �������
    int cy = coords[1];  // y �������

    SubDomain sd;
    sd.i0 = iBeg[cx];
    sd.i1 = iEnd[cx];
    sd.j0 = jBeg[cy];
    sd.j1 = jEnd[cy];
    int nx = sd.nx();
    int ny = sd.ny();

    // ���ڽ��̱�ţ��������߽磬��Ϊ MPI_PROC_NULL��
    int nbr_left, nbr_right, nbr_down, nbr_up;
    MPI_Cart_shift(comm2d, 0, 1, &nbr_left, &nbr_right); // x ����
    MPI_Cart_shift(comm2d, 1, 1, &nbr_down, &nbr_up);     // y ����

    // ÿ�����̴�ӡ�Լ���������Ϣ���������������
    std::cout << "Rank " << world_rank
        << " coords(" << cx << "," << cy << ")"
        << "  local nx=" << nx << " ny=" << ny
        << "  i:[" << sd.i0 << "," << sd.i1 << "]"
        << "  j:[" << sd.j0 << "," << sd.j1 << "]\n";

    MPI_Barrier(comm2d);

    // ---------- 3. ����ȫ��ϵ����ÿ������һ�ݣ� ----------
    Coeffs C(M, N);

    // ---------- 4. MPI-PCG ��� (��Ŀ�� 5 ��) ----------
    PCGResult R = solve_pcg_mpi(C, sd, comm2d,
        nbr_left, nbr_right,
        nbr_down, nbr_up,
        delta, 20000);

    if (world_rank == 0) {
        std::cout << std::fixed << std::setprecision(8);
        std::cout << "MPI PCG finished: iterations = " << R.iters
            << ", ||r||_E = " << R.resNorm
            << ", time = " << R.timeSec << " s\n";
        std::cout << "You can now compare this time with your "
            "sequential / OpenMP version on the same grid.\n";
    }

    MPI_Finalize();
    return 0;
}
