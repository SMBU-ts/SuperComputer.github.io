#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <chrono>
#include <algorithm>
#include <string>

#ifdef _OPENMP
#include <omp.h>
#else
inline void omp_set_num_threads(int) {}
inline int  omp_get_max_threads() { return 1; }
inline int  omp_get_num_threads() { return 1; }
inline int  omp_get_thread_num() { return 0; }
#endif

using namespace std;

/*
  OpenMP PCG (Jacobi-preconditioned Conjugate Gradient) for fictitious-domain Poisson:
    -(a w_x)_x - (b w_y)_y = F  on interior,  w=0 on box boundary.
  Geometry (case #6): D = { (x,y): |x| + |y| < 2,  y < 1 }
  Box �� = [-2,2] x [-2,1]
  �� = h^2 with h=max(h1,h2).
*/

struct Grid {
    int M, N;
    double A1 = -2, B1 = 2, A2 = -2, B2 = 1;
    double h1, h2, h, eps;   // eps = h^2
    vector<double> x, y;
    Grid(int M_, int N_) : M(M_), N(N_) {
        h1 = (B1 - A1) / M;
        h2 = (B2 - A2) / N;
        h = (h1 > h2 ? h1 : h2);
        eps = h * h;
        x.resize(M + 1); y.resize(N + 1);
        for (int i = 0; i <= M; i++) x[i] = A1 + i * h1;
        for (int j = 0; j <= N; j++) y[j] = A2 + j * h2;
    }
};

// D = {|x|+|y|<2, y<1}
inline bool inD(double x, double y) { return (fabs(x) + fabs(y) < 2.0) && (y < 1.0); }

double vert_len_in_D(double x0, double y0, double y1) {
    double L = -2.0 + fabs(x0);
    double U = min(2.0 - fabs(x0), 1.0);
    if (L >= U) return 0.0;
    double a = max(L, min(y0, y1));
    double b = min(U, max(y0, y1));
    return (b > a ? (b - a) : 0.0);
}

double horiz_len_in_D(double y0, double x0, double x1) {
    if (y0 >= 1.0) return 0.0;
    if (fabs(y0) >= 2.0) return 0.0;
    double L = -2.0 + fabs(y0);
    double U = 2.0 - fabs(y0);
    if (L >= U) return 0.0;
    double a = max(L, min(x0, x1));
    double b = min(U, max(x0, x1));
    return (b > a ? (b - a) : 0.0);
}

double cell_area_fraction_in_D(double xL, double xR, double yB, double yT, int samples = 5) {
    int cnt = 0, tot = samples * samples;
    for (int si = 0; si < samples; ++si) {
        double xi = xL + (si + 0.5) * (xR - xL) / samples;
        for (int sj = 0; sj < samples; ++sj) {
            double yj = yB + (sj + 0.5) * (yT - yB) / samples;
            if (inD(xi, yj)) cnt++;
        }
    }
    return double(cnt) / double(tot);
}

struct Problem {
    Grid G;
    vector<vector<double>> a, b, F;

    Problem(int M, int N) :G(M, N) {
        a.assign(G.M + 1, vector<double>(G.N + 1, 0.0));
        b.assign(G.M + 1, vector<double>(G.N + 1, 0.0));
        F.assign(G.M + 1, vector<double>(G.N + 1, 0.0));
        build_coefficients();
        build_rhs();
    }

    void build_coefficients() {
#pragma omp parallel for schedule(static)
        for (int i = 1; i <= G.M; i++) {
            for (int j = 1; j <= G.N; j++) {
                double xh = G.x[i] - 0.5 * G.h1;
                double y0 = G.y[j] - 0.5 * G.h2, y1 = G.y[j] + 0.5 * G.h2;
                double l = vert_len_in_D(xh, y0, y1);
                a[i][j] = (l / G.h2) + (1.0 - l / G.h2) / G.eps;
            }
        }
#pragma omp parallel for schedule(static)
        for (int i = 1; i <= G.M; i++) {
            for (int j = 1; j <= G.N; j++) {
                double x0 = G.x[i] - 0.5 * G.h1, x1 = G.x[i] + 0.5 * G.h1;
                double yh = G.y[j] - 0.5 * G.h2;
                double l = horiz_len_in_D(yh, x0, x1);
                b[i][j] = (l / G.h1) + (1.0 - l / G.h1) / G.eps;
            }
        }
    }

    void build_rhs() {
#pragma omp parallel for schedule(static)
        for (int i = 1; i < G.M; i++) {
            for (int j = 1; j < G.N; j++) {
                double xL = G.x[i] - 0.5 * G.h1, xR = G.x[i] + 0.5 * G.h1;
                double yB = G.y[j] - 0.5 * G.h2, yT = G.y[j] + 0.5 * G.h2;
                F[i][j] = cell_area_fraction_in_D(xL, xR, yB, yT, 5); // f=1 in D
            }
        }
    }

    // y = A w
    void apply_A(const vector<vector<double>>& w, vector<vector<double>>& y) const {
#pragma omp parallel for schedule(static)
        for (int i = 1; i < G.M; i++) {
            for (int j = 1; j < G.N; j++) {
                double termx = (a[i + 1][j] * (w[i + 1][j] - w[i][j]) - a[i][j] * (w[i][j] - w[i - 1][j])) / (G.h1 * G.h1);
                double termy = (b[i][j + 1] * (w[i][j + 1] - w[i][j]) - b[i][j] * (w[i][j] - w[i][j - 1])) / (G.h2 * G.h2);
                y[i][j] = -(termx + termy);
            }
        }
    }

    // z = D^{-1} r
    void apply_Dinv(const vector<vector<double>>& r, vector<vector<double>>& z) const {
#pragma omp parallel for schedule(static)
        for (int i = 1; i < G.M; i++) {
            for (int j = 1; j < G.N; j++) {
                double Dij = ((a[i + 1][j] + a[i][j]) / (G.h1 * G.h1) + (b[i][j + 1] + b[i][j]) / (G.h2 * G.h2));
                z[i][j] = r[i][j] / Dij;
            }
        }
    }

    // (u,v)_E
    double inner(const vector<vector<double>>& u, const vector<vector<double>>& v) const {
        double s = 0.0;
#pragma omp parallel for reduction(+:s) schedule(static)
        for (int i = 1; i < G.M; i++) {
            double si = 0.0;
            for (int j = 1; j < G.N; j++) si += u[i][j] * v[i][j];
            s += si;
        }
        return s * (G.h1 * G.h2);
    }

    double normE(const vector<vector<double>>& u) const { return sqrt(inner(u, u)); }

    struct Result { int iters = 0; double lastRes = 0.0; double timeSec = 0.0; vector<vector<double>> w; };

    // ���� �Ƚ��� PCG�������ڻ����� inner() ��ɣ������а�ȫ�� reduction��
    Result solve_pcg(double delta, int maxIter = 20000, bool verbose = false) {
        vector<vector<double>> w(G.M + 1, vector<double>(G.N + 1, 0.0));
        vector<vector<double>> r(G.M + 1, vector<double>(G.N + 1, 0.0));
        vector<vector<double>> z(G.M + 1, vector<double>(G.N + 1, 0.0));
        vector<vector<double>> p(G.M + 1, vector<double>(G.N + 1, 0.0));
        vector<vector<double>> Ap(G.M + 1, vector<double>(G.N + 1, 0.0));

        auto t0 = chrono::high_resolution_clock::now();

        // r0 = F - A w0
        apply_A(w, Ap);
#pragma omp parallel for schedule(static)
        for (int i = 1; i < G.M; i++)
            for (int j = 1; j < G.N; j++)
                r[i][j] = F[i][j] - Ap[i][j];

        apply_Dinv(r, z);
#pragma omp parallel for schedule(static)
        for (int i = 1; i < G.M; i++)
            for (int j = 1; j < G.N; j++)
                p[i][j] = z[i][j];

        double rz_old = inner(r, z);
        double resn = normE(r);
        if (verbose) cerr << "iter 0  res_norm = " << resn << "\n";
        if (resn < delta) {
            auto t1 = chrono::high_resolution_clock::now();
            Result R; R.iters = 0; R.lastRes = resn; R.timeSec = chrono::duration<double>(t1 - t0).count(); R.w.swap(w);
            return R;
        }

        int k = 0;
        for (; k < maxIter; ++k) {
            apply_A(p, Ap);
            double pAp = inner(p, Ap);
            double alpha = rz_old / pAp;

            // w = w + alpha p; r = r - alpha Ap
#pragma omp parallel for schedule(static)
            for (int i = 1; i < G.M; i++)
                for (int j = 1; j < G.N; j++) {
                    w[i][j] += alpha * p[i][j];
                    r[i][j] -= alpha * Ap[i][j];
                }

            resn = normE(r);
            if (resn < delta) { ++k; break; }

            apply_Dinv(r, z);
            double rz_new = inner(r, z);
            double beta = rz_new / rz_old;
            rz_old = rz_new;

            // p = z + beta p
#pragma omp parallel for schedule(static)
            for (int i = 1; i < G.M; i++)
                for (int j = 1; j < G.N; j++)
                    p[i][j] = z[i][j] + beta * p[i][j];
        }

        auto t1 = chrono::high_resolution_clock::now();
        Result R;
        R.iters = k;
        R.lastRes = resn;
        R.timeSec = chrono::duration<double>(t1 - t0).count();
        R.w.swap(w);
        return R;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int M = 400, N = 600;           // ��800��1200��
    const double delta = 1e-6;

    vector<int> threads = { 2,4,8,16 }; // {4��8��16��32}

#ifdef _OPENMP
    omp_set_dynamic(0);
    omp_set_max_active_levels(1);
#endif

    cout << fixed << setprecision(10);
    cout << "# OpenMP PCG (Jacobi) �� fictitious domain Poisson (case #6)\n";
    cout << "# Grid (M,N) = (" << M << "," << N << "), epsilon = h^2, stop when ||r||_E < " << delta << ".\n";
    cout << "# Columns: threads  iterations  res_norm  time_sec  speedup_vs_first\n";

    double baseline = -1.0;
    for (int t : threads) {
        omp_set_num_threads(t);
        Problem P(M, N);
        auto R = P.solve_pcg(delta, 20000, /*verbose=*/false);

        if (baseline < 0) baseline = R.timeSec;
        double speed = baseline / R.timeSec;

        cout << setw(7) << t << "  "
            << setw(10) << R.iters << "  "
            << setw(12) << R.lastRes << "  "
            << setw(10) << R.timeSec << "  "
            << setw(12) << speed << "\n";

        if (t == threads.front()) {
            ofstream fo(("solution_PCG_M" + to_string(M) + "_N" + to_string(N) + ".csv").c_str());
            fo << "x,y,u\n";
            for (int i = 0; i <= P.G.M; i++)
                for (int j = 0; j <= P.G.N; j++)
                    fo << P.G.x[i] << "," << P.G.y[j] << "," << R.w[i][j] << "\n";
            fo.close();
            cerr << "Saved solution CSV.\n";
        }
    }
    return 0;
}
